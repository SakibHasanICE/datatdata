use master
select * from student