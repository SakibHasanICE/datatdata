SELECT table_name FROM information_schema.tables
select * from titles 
create view view_data 
as

select * from titles where type='business'
select * from view_data
